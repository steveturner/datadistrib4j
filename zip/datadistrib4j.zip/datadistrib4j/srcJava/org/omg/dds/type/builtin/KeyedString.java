/* Copyright 2010, Object Management Group, Inc.
 * Copyright 2010, PrismTech, Inc.
 * Copyright 2010, Real-Time Innovations, Inc.
 * All rights reserved.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.omg.dds.type.builtin;

import java.io.Serializable;

import org.omg.dds.core.DDSObject;


public interface KeyedString extends Cloneable, Serializable, DDSObject
{
    /**
     * @param key the key to set
     * 
     * @return  this
     */
    public KeyedString setKey(CharSequence key);

    /**
     * @return the key
     */
    public String getKey();

    /**
     * @param value the value to set
     * 
     * @return  this
     */
    public KeyedString setValue(CharSequence value);

    /**
     * @return the value
     */
    public String getValue();


    // -----------------------------------------------------------------------

    /**
     * Overwrite the state of this object with that of the given object.
     */
    public void copyFrom(KeyedString src);

    public KeyedString clone();
}
