/**
 * The Publication Module contains the {@link org.omg.dds.pub.Publisher} and
 * {@link org.omg.dds.pub.DataWriter} interfaces as well as the
 * {@link org.omg.dds.pub.PublisherListener} and
 * {@link org.omg.dds.pub.DataWriterListener} interfaces, and more generally,
 * all that is needed on the publication side.
 */
package org.omg.dds.pub;
